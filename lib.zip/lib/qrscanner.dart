

import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';


class QRscanner extends StatefulWidget{
  const QRscanner({Key? key}) : super(key: key);

  @override
  State<QRscanner> createState() => _QRscanner();

}


class _QRscanner extends State<QRscanner> {
  @override
  Widget build(BuildContext context) {

    return MobileScanner(
        allowDuplicates: false,
        onDetect: (barcode, args) {
          if (barcode.rawValue == null) {
            debugPrint('Failed to scan Barcode');
          } else {
            final String code = barcode.rawValue!;
            debugPrint('Barcode found! $code');
            ScaffoldMessenger.of(context).showSnackBar(new SnackBar(
              content: Text('Snackbar message'),
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(24),
              ),
              margin: EdgeInsets.only(
                  bottom: MediaQuery.of(context).size.height - 100- 32,
                  right: 20,
                  left: 20),
            ));
          }
        });

  }
}